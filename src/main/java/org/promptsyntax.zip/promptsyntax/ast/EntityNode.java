package org.promptsyntax.ast;

import java.util.ArrayList;
import java.util.List;

public class EntityNode {
    public final String name;
    public final List<FieldNode> fields = new ArrayList<>();

    public EntityNode(String name) {
        this.name = name;
    }

    public void addField(FieldNode field) {
        fields.add(field);
    }
}