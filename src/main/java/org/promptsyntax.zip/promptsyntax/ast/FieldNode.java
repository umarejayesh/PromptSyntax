package org.promptsyntax.ast;

public class FieldNode {
    public final String name;
    public final String type;

    public FieldNode(String name, String type) {
        this.name = name;
        this.type = type;
    }
}