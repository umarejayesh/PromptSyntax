
package org.promptsyntax.ir;

public class IRField {
    public final String name;
    public final String type;

    public IRField(String name, String type) {
        this.name = name;
        this.type = type;
    }
}