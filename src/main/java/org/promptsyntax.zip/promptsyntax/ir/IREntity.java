package org.promptsyntax.ir;

import java.util.ArrayList;
import java.util.List;

public class IREntity {
    public final String name;
    public final List<IRField> fields = new ArrayList<>();

    public IREntity(String name) {
        this.name = name;
    }

    public void addField(IRField field) {
        fields.add(field);
    }
}
